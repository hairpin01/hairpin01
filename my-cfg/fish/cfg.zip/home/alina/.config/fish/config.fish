# env
# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
  function __fish_ferium_global_optspecs
      string join \n t/threads= github-token= curseforge-api-key= c/config-file= h/help V/version
  end

  function __fish_ferium_needs_command
      # Figure out if the current invocation already has a command.
      set -l cmd (commandline -opc)
      set -e cmd[1]
      argparse -s (__fish_ferium_global_optspecs) -- $cmd 2>/dev/null
      or return
      if set -q argv[1]
          # Also print the command, so this can be used to figure out what it is.
          echo $argv[1]
          return 1
      end
      return 0
  end

  function __fish_ferium_using_subcommand
      set -l cmd (__fish_ferium_needs_command)
      test -z "$cmd"
      and return 1
      contains -- $cmd[1] $argv
  end

  complete -c ferium -n "__fish_ferium_needs_command" -s t -l threads -d 'Sets the number of worker threads the tokio runtime will use. You can also use the environment variable `TOKIO_WORKER_THREADS`' -r
  complete -c ferium -n "__fish_ferium_needs_command" -l github-token -l gh -d 'Set a GitHub personal access token for increasing the GitHub API rate limit. You can also use the environment variable `GITHUB_TOKEN`' -r
  complete -c ferium -n "__fish_ferium_needs_command" -l curseforge-api-key -l cf -d 'Set a custom Curseforge API key. You can also use the environment variable `CURSEFORGE_API_KEY`' -r
  complete -c ferium -n "__fish_ferium_needs_command" -s c -l config-file -l config -l conf -d 'Set the file to read the config from. This does not change the `cache` and `tmp` directories. You can also use the environment variable `FERIUM_CONFIG_FILE`' -r -F
  complete -c ferium -n "__fish_ferium_needs_command" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_needs_command" -s V -l version -d 'Print version'
  complete -c ferium -n "__fish_ferium_needs_command" -f -a "add" -d 'Add mods to the profile'
  complete -c ferium -n "__fish_ferium_needs_command" -f -a "scan" -d 'Scan the profile\'s output directory (or the specified directory) for mods and add them to the profile'
  complete -c ferium -n "__fish_ferium_needs_command" -f -a "complete" -d 'Print shell auto completions for the specified shell'
  complete -c ferium -n "__fish_ferium_needs_command" -f -a "list" -d 'List all the mods in the profile, and with some their metadata if verbose'
  complete -c ferium -n "__fish_ferium_needs_command" -f -a "mods" -d 'List all the mods in the profile, and with some their metadata if verbose'
  complete -c ferium -n "__fish_ferium_needs_command" -f -a "modpack" -d 'Add, configure, delete, switch, list, or upgrade modpacks'
  complete -c ferium -n "__fish_ferium_needs_command" -f -a "modpacks" -d 'List all the modpacks with their data'
  complete -c ferium -n "__fish_ferium_needs_command" -f -a "profile" -d 'Create, configure, delete, switch, or list profiles'
  complete -c ferium -n "__fish_ferium_needs_command" -f -a "profiles" -d 'List all the profiles with their data'
  complete -c ferium -n "__fish_ferium_needs_command" -f -a "remove" -d 'Remove mods and/or repositories from the profile. Optionally, provide a list of names or IDs of the mods to remove'
  complete -c ferium -n "__fish_ferium_needs_command" -f -a "rm" -d 'Remove mods and/or repositories from the profile. Optionally, provide a list of names or IDs of the mods to remove'
  complete -c ferium -n "__fish_ferium_needs_command" -f -a "upgrade" -d 'Download and install the latest compatible version of your mods'
  complete -c ferium -n "__fish_ferium_needs_command" -f -a "download" -d 'Download and install the latest compatible version of your mods'
  complete -c ferium -n "__fish_ferium_needs_command" -f -a "install" -d 'Download and install the latest compatible version of your mods'
  complete -c ferium -n "__fish_ferium_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
  complete -c ferium -n "__fish_ferium_using_subcommand add" -s f -l force -l override -d 'Temporarily ignore game version and mod loader checks and add the mod anyway'
  complete -c ferium -n "__fish_ferium_using_subcommand add" -s V -l ignore-game-version -d 'The game version will not be checked for this mod. Only works when adding a single mod'
  complete -c ferium -n "__fish_ferium_using_subcommand add" -s M -l ignore-mod-loader -d 'The mod loader will not be checked for this mod. Only works when adding a single mod'
  complete -c ferium -n "__fish_ferium_using_subcommand add" -s h -l help -d 'Print help (see more with \'--help\')'
  complete -c ferium -n "__fish_ferium_using_subcommand scan" -s p -l platform -d 'The platform you prefer mods to be added from. If a mod isn\'t available from this platform, the other platform will still be used' -r -f -a "{modrinth\t'',curseforge\t''}"
  complete -c ferium -n "__fish_ferium_using_subcommand scan" -s d -l directory -l dir -l folder -d 'The directory to scan mods from. Defaults to the profile\'s output directory' -r -F
  complete -c ferium -n "__fish_ferium_using_subcommand scan" -s f -l force -l override -d 'Temporarily ignore game version and mod loader checks and add the mods anyway'
  complete -c ferium -n "__fish_ferium_using_subcommand scan" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand complete" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand list" -s v -l verbose -d 'Show additional information about the mod'
  complete -c ferium -n "__fish_ferium_using_subcommand list" -s m -l markdown -l md -d 'Output information in markdown format and alphabetical order'
  complete -c ferium -n "__fish_ferium_using_subcommand list" -s h -l help -d 'Print help (see more with \'--help\')'
  complete -c ferium -n "__fish_ferium_using_subcommand mods" -s v -l verbose -d 'Show additional information about the mod'
  complete -c ferium -n "__fish_ferium_using_subcommand mods" -s m -l markdown -l md -d 'Output information in markdown format and alphabetical order'
  complete -c ferium -n "__fish_ferium_using_subcommand mods" -s h -l help -d 'Print help (see more with \'--help\')'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and not __fish_seen_subcommand_from add configure config conf delete remove rm info list switch upgrade download install help" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and not __fish_seen_subcommand_from add configure config conf delete remove rm info list switch upgrade download install help" -f -a "add" -d 'Add a modpack to the config'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and not __fish_seen_subcommand_from add configure config conf delete remove rm info list switch upgrade download install help" -f -a "configure" -d 'Configure the current modpack\'s output directory and installation of overrides. Optionally, provide the settings to change as arguments'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and not __fish_seen_subcommand_from add configure config conf delete remove rm info list switch upgrade download install help" -f -a "config" -d 'Configure the current modpack\'s output directory and installation of overrides. Optionally, provide the settings to change as arguments'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and not __fish_seen_subcommand_from add configure config conf delete remove rm info list switch upgrade download install help" -f -a "conf" -d 'Configure the current modpack\'s output directory and installation of overrides. Optionally, provide the settings to change as arguments'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and not __fish_seen_subcommand_from add configure config conf delete remove rm info list switch upgrade download install help" -f -a "delete" -d 'Delete a modpack. Optionally, provide the name of the modpack to delete'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and not __fish_seen_subcommand_from add configure config conf delete remove rm info list switch upgrade download install help" -f -a "remove" -d 'Delete a modpack. Optionally, provide the name of the modpack to delete'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and not __fish_seen_subcommand_from add configure config conf delete remove rm info list switch upgrade download install help" -f -a "rm" -d 'Delete a modpack. Optionally, provide the name of the modpack to delete'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and not __fish_seen_subcommand_from add configure config conf delete remove rm info list switch upgrade download install help" -f -a "info" -d 'Show information about the current modpack'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and not __fish_seen_subcommand_from add configure config conf delete remove rm info list switch upgrade download install help" -f -a "list" -d 'List all the modpacks with their data'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and not __fish_seen_subcommand_from add configure config conf delete remove rm info list switch upgrade download install help" -f -a "switch" -d 'Switch between different modpacks. Optionally, provide the name of the modpack to switch to'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and not __fish_seen_subcommand_from add configure config conf delete remove rm info list switch upgrade download install help" -f -a "upgrade" -d 'Download and install the latest version of the modpack'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and not __fish_seen_subcommand_from add configure config conf delete remove rm info list switch upgrade download install help" -f -a "download" -d 'Download and install the latest version of the modpack'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and not __fish_seen_subcommand_from add configure config conf delete remove rm info list switch upgrade download install help" -f -a "install" -d 'Download and install the latest version of the modpack'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and not __fish_seen_subcommand_from add configure config conf delete remove rm info list switch upgrade download install help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from add" -s o -l output-dir -d 'The Minecraft instance directory to install the modpack to' -r -f -a "(__fish_complete_directories)"
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from add" -s i -l install-overrides -d 'Whether to install the modpack\'s overrides to the output directory. This will override existing files when upgrading' -r -f -a "{true\t'',false\t''}"
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from add" -s h -l help -d 'Print help (see more with \'--help\')'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from configure" -s o -l output-dir -d 'The Minecraft instance directory to install the modpack to' -r -f -a "(__fish_complete_directories)"
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from configure" -s i -l install-overrides -d 'Whether to install the modpack\'s overrides to the output directory. This will override existing files when upgrading' -r -f -a "{true\t'',false\t''}"
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from configure" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from config" -s o -l output-dir -d 'The Minecraft instance directory to install the modpack to' -r -f -a "(__fish_complete_directories)"
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from config" -s i -l install-overrides -d 'Whether to install the modpack\'s overrides to the output directory. This will override existing files when upgrading' -r -f -a "{true\t'',false\t''}"
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from config" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from conf" -s o -l output-dir -d 'The Minecraft instance directory to install the modpack to' -r -f -a "(__fish_complete_directories)"
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from conf" -s i -l install-overrides -d 'Whether to install the modpack\'s overrides to the output directory. This will override existing files when upgrading' -r -f -a "{true\t'',false\t''}"
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from conf" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from delete" -s s -l switch-to -d 'The name of the profile to switch to afterwards' -r
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from delete" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from remove" -s s -l switch-to -d 'The name of the profile to switch to afterwards' -r
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from remove" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from rm" -s s -l switch-to -d 'The name of the profile to switch to afterwards' -r
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from rm" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from info" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from switch" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from upgrade" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from download" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from install" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from help" -f -a "add" -d 'Add a modpack to the config'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from help" -f -a "configure" -d 'Configure the current modpack\'s output directory and installation of overrides. Optionally, provide the settings to change as arguments'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from help" -f -a "delete" -d 'Delete a modpack. Optionally, provide the name of the modpack to delete'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from help" -f -a "info" -d 'Show information about the current modpack'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from help" -f -a "list" -d 'List all the modpacks with their data'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from help" -f -a "switch" -d 'Switch between different modpacks. Optionally, provide the name of the modpack to switch to'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from help" -f -a "upgrade" -d 'Download and install the latest version of the modpack'
  complete -c ferium -n "__fish_ferium_using_subcommand modpack; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
  complete -c ferium -n "__fish_ferium_using_subcommand modpacks" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and not __fish_seen_subcommand_from configure config conf create new delete remove rm info list switch help" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and not __fish_seen_subcommand_from configure config conf create new delete remove rm info list switch help" -f -a "configure" -d 'Configure the current profile\'s name, Minecraft version, mod loader, and output directory. Optionally, provide the settings to change as arguments'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and not __fish_seen_subcommand_from configure config conf create new delete remove rm info list switch help" -f -a "config" -d 'Configure the current profile\'s name, Minecraft version, mod loader, and output directory. Optionally, provide the settings to change as arguments'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and not __fish_seen_subcommand_from configure config conf create new delete remove rm info list switch help" -f -a "conf" -d 'Configure the current profile\'s name, Minecraft version, mod loader, and output directory. Optionally, provide the settings to change as arguments'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and not __fish_seen_subcommand_from configure config conf create new delete remove rm info list switch help" -f -a "create" -d 'Create a new profile. Optionally, provide the settings as arguments. Use the import flag to import mods from another profile'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and not __fish_seen_subcommand_from configure config conf create new delete remove rm info list switch help" -f -a "new" -d 'Create a new profile. Optionally, provide the settings as arguments. Use the import flag to import mods from another profile'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and not __fish_seen_subcommand_from configure config conf create new delete remove rm info list switch help" -f -a "delete" -d 'Delete a profile. Optionally, provide the name of the profile to delete'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and not __fish_seen_subcommand_from configure config conf create new delete remove rm info list switch help" -f -a "remove" -d 'Delete a profile. Optionally, provide the name of the profile to delete'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and not __fish_seen_subcommand_from configure config conf create new delete remove rm info list switch help" -f -a "rm" -d 'Delete a profile. Optionally, provide the name of the profile to delete'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and not __fish_seen_subcommand_from configure config conf create new delete remove rm info list switch help" -f -a "info" -d 'Show information about the current profile'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and not __fish_seen_subcommand_from configure config conf create new delete remove rm info list switch help" -f -a "list" -d 'List all the profiles with their data'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and not __fish_seen_subcommand_from configure config conf create new delete remove rm info list switch help" -f -a "switch" -d 'Switch between different profiles. Optionally, provide the name of the profile to switch to'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and not __fish_seen_subcommand_from configure config conf create new delete remove rm info list switch help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from configure" -s v -l game-version -d 'The Minecraft version to check compatibility for' -r
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from configure" -s m -l mod-loader -d 'The mod loader to check compatibility for' -r -f -a "{quilt\t'',fabric\t'',forge\t'',neo-forge\t''}"
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from configure" -s n -l name -d 'The name of the profile' -r
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from configure" -s o -l output-dir -d 'The directory to output mods to' -r -f -a "(__fish_complete_directories)"
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from configure" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from config" -s v -l game-version -d 'The Minecraft version to check compatibility for' -r
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from config" -s m -l mod-loader -d 'The mod loader to check compatibility for' -r -f -a "{quilt\t'',fabric\t'',forge\t'',neo-forge\t''}"
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from config" -s n -l name -d 'The name of the profile' -r
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from config" -s o -l output-dir -d 'The directory to output mods to' -r -f -a "(__fish_complete_directories)"
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from config" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from conf" -s v -l game-version -d 'The Minecraft version to check compatibility for' -r
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from conf" -s m -l mod-loader -d 'The mod loader to check compatibility for' -r -f -a "{quilt\t'',fabric\t'',forge\t'',neo-forge\t''}"
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from conf" -s n -l name -d 'The name of the profile' -r
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from conf" -s o -l output-dir -d 'The directory to output mods to' -r -f -a "(__fish_complete_directories)"
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from conf" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from create" -s i -l import -l copy -l duplicate -d 'Copy over the mods from an existing profile. Optionally, provide the name of the profile to import mods from' -r
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from create" -s v -l game-version -d 'The Minecraft version to check compatibility for' -r
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from create" -s m -l mod-loader -d 'The mod loader to check compatibility for' -r -f -a "{quilt\t'',fabric\t'',forge\t'',neo-forge\t''}"
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from create" -s n -l name -d 'The name of the profile' -r
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from create" -s o -l output-dir -d 'The directory to output mods to' -r -f -a "(__fish_complete_directories)"
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from create" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from new" -s i -l import -l copy -l duplicate -d 'Copy over the mods from an existing profile. Optionally, provide the name of the profile to import mods from' -r
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from new" -s v -l game-version -d 'The Minecraft version to check compatibility for' -r
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from new" -s m -l mod-loader -d 'The mod loader to check compatibility for' -r -f -a "{quilt\t'',fabric\t'',forge\t'',neo-forge\t''}"
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from new" -s n -l name -d 'The name of the profile' -r
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from new" -s o -l output-dir -d 'The directory to output mods to' -r -f -a "(__fish_complete_directories)"
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from new" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from delete" -s s -l switch-to -d 'The name of the profile to switch to afterwards' -r
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from delete" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from remove" -s s -l switch-to -d 'The name of the profile to switch to afterwards' -r
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from remove" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from rm" -s s -l switch-to -d 'The name of the profile to switch to afterwards' -r
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from rm" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from info" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from switch" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from help" -f -a "configure" -d 'Configure the current profile\'s name, Minecraft version, mod loader, and output directory. Optionally, provide the settings to change as arguments'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from help" -f -a "create" -d 'Create a new profile. Optionally, provide the settings as arguments. Use the import flag to import mods from another profile'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from help" -f -a "delete" -d 'Delete a profile. Optionally, provide the name of the profile to delete'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from help" -f -a "info" -d 'Show information about the current profile'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from help" -f -a "list" -d 'List all the profiles with their data'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from help" -f -a "switch" -d 'Switch between different profiles. Optionally, provide the name of the profile to switch to'
  complete -c ferium -n "__fish_ferium_using_subcommand profile; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
  complete -c ferium -n "__fish_ferium_using_subcommand profiles" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand remove" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand rm" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand upgrade" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand download" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand install" -s h -l help -d 'Print help'
  complete -c ferium -n "__fish_ferium_using_subcommand help; and not __fish_seen_subcommand_from add scan complete list modpack modpacks profile profiles remove upgrade help" -f -a "add" -d 'Add mods to the profile'
  complete -c ferium -n "__fish_ferium_using_subcommand help; and not __fish_seen_subcommand_from add scan complete list modpack modpacks profile profiles remove upgrade help" -f -a "scan" -d 'Scan the profile\'s output directory (or the specified directory) for mods and add them to the profile'
  complete -c ferium -n "__fish_ferium_using_subcommand help; and not __fish_seen_subcommand_from add scan complete list modpack modpacks profile profiles remove upgrade help" -f -a "complete" -d 'Print shell auto completions for the specified shell'
  complete -c ferium -n "__fish_ferium_using_subcommand help; and not __fish_seen_subcommand_from add scan complete list modpack modpacks profile profiles remove upgrade help" -f -a "list" -d 'List all the mods in the profile, and with some their metadata if verbose'
  complete -c ferium -n "__fish_ferium_using_subcommand help; and not __fish_seen_subcommand_from add scan complete list modpack modpacks profile profiles remove upgrade help" -f -a "modpack" -d 'Add, configure, delete, switch, list, or upgrade modpacks'
  complete -c ferium -n "__fish_ferium_using_subcommand help; and not __fish_seen_subcommand_from add scan complete list modpack modpacks profile profiles remove upgrade help" -f -a "modpacks" -d 'List all the modpacks with their data'
  complete -c ferium -n "__fish_ferium_using_subcommand help; and not __fish_seen_subcommand_from add scan complete list modpack modpacks profile profiles remove upgrade help" -f -a "profile" -d 'Create, configure, delete, switch, or list profiles'
  complete -c ferium -n "__fish_ferium_using_subcommand help; and not __fish_seen_subcommand_from add scan complete list modpack modpacks profile profiles remove upgrade help" -f -a "profiles" -d 'List all the profiles with their data'
  complete -c ferium -n "__fish_ferium_using_subcommand help; and not __fish_seen_subcommand_from add scan complete list modpack modpacks profile profiles remove upgrade help" -f -a "remove" -d 'Remove mods and/or repositories from the profile. Optionally, provide a list of names or IDs of the mods to remove'
  complete -c ferium -n "__fish_ferium_using_subcommand help; and not __fish_seen_subcommand_from add scan complete list modpack modpacks profile profiles remove upgrade help" -f -a "upgrade" -d 'Download and install the latest compatible version of your mods'
  complete -c ferium -n "__fish_ferium_using_subcommand help; and not __fish_seen_subcommand_from add scan complete list modpack modpacks profile profiles remove upgrade help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
  complete -c ferium -n "__fish_ferium_using_subcommand help; and __fish_seen_subcommand_from modpack" -f -a "add" -d 'Add a modpack to the config'
  complete -c ferium -n "__fish_ferium_using_subcommand help; and __fish_seen_subcommand_from modpack" -f -a "configure" -d 'Configure the current modpack\'s output directory and installation of overrides. Optionally, provide the settings to change as arguments'
  complete -c ferium -n "__fish_ferium_using_subcommand help; and __fish_seen_subcommand_from modpack" -f -a "delete" -d 'Delete a modpack. Optionally, provide the name of the modpack to delete'
  complete -c ferium -n "__fish_ferium_using_subcommand help; and __fish_seen_subcommand_from modpack" -f -a "info" -d 'Show information about the current modpack'
  complete -c ferium -n "__fish_ferium_using_subcommand help; and __fish_seen_subcommand_from modpack" -f -a "list" -d 'List all the modpacks with their data'
  complete -c ferium -n "__fish_ferium_using_subcommand help; and __fish_seen_subcommand_from modpack" -f -a "switch" -d 'Switch between different modpacks. Optionally, provide the name of the modpack to switch to'
  complete -c ferium -n "__fish_ferium_using_subcommand help; and __fish_seen_subcommand_from modpack" -f -a "upgrade" -d 'Download and install the latest version of the modpack'
  complete -c ferium -n "__fish_ferium_using_subcommand help; and __fish_seen_subcommand_from profile" -f -a "configure" -d 'Configure the current profile\'s name, Minecraft version, mod loader, and output directory. Optionally, provide the settings to change as arguments'
  complete -c ferium -n "__fish_ferium_using_subcommand help; and __fish_seen_subcommand_from profile" -f -a "create" -d 'Create a new profile. Optionally, provide the settings as arguments. Use the import flag to import mods from another profile'
  complete -c ferium -n "__fish_ferium_using_subcommand help; and __fish_seen_subcommand_from profile" -f -a "delete" -d 'Delete a profile. Optionally, provide the name of the profile to delete'
  complete -c ferium -n "__fish_ferium_using_subcommand help; and __fish_seen_subcommand_from profile" -f -a "info" -d 'Show information about the current profile'
  complete -c ferium -n "__fish_ferium_using_subcommand help; and __fish_seen_subcommand_from profile" -f -a "list" -d 'List all the profiles with their data'
  complete -c ferium -n "__fish_ferium_using_subcommand help; and __fish_seen_subcommand_from profile" -f -a "switch" -d 'Switch between different profiles. Optionally, provide the name of the profile to switch to'

set -g PATH "$HOME/.config/bspwm/bin:$PATH"
set -g fish_greeting ""
set USERNAME 'Шмелька'
set HOSTNAME $(hostname)
set -g HTTPS_PROXY http://127.0.0.1:12335
set -g HTTP_PROXY http://127.0.0.1:12335
set -g OBS_WEB_PASS "FQf9VuvCJPAKDBFg"

alias check_ai 'python3 ~/test/hidden-characters-detector/hidden-characters-detector.py'

sh ~/.profile
set -g PATH /home/alina/.opencode/bin:$PATH

# bun
set -g BUN_INSTALL "$HOME/.bun"
set -g PATH "$BUN_INSTALL/bin:$PATH"
set -g PATH "$HOME/.local/bin:$PATH"

set -g PATH "/home/alina/.local/.ai-terminal/bin:$PATH"

set -g PYENV_ROOT "$HOME/.pyenv"
if test -d $PYENV_ROOT/bin 
	set -g PATH "$PYENV_ROOT/bin:$PATH"
end

set -g JAVA_HOME "/usr/lib/jvm/java-17-openjdk"
set -g PATH "$PATH:$JAVA_HOME/bin"
set -g ANDROID_SDK_ROOT "$HOME/Android/Sdk"
set -g PATH "$PATH:$ANDROID_SDK_ROOT/cmdline-tools/latest/bin:$ANDROID_SDK_ROOT/platform-tools"

#THIS MUST BE AT THE END OF THE FILE FOR SDKMAN TO WORK!!!
set -g SDKMAN_DIR "$HOME/.sdkman"
# [[ -s "$HOME/.sdkman/bin/sdkman-init.sh" ]] && source "$HOME/.sdkman/bin/sdkman-init.sh"
set -g PATH "$PATH:/opt/gradle/gradle-8.12/bin"
source "$HOME/.cargo/env.fish"
# abbr
abbr -a hcd $HOME/test/hidden-characters-detector/hidden-characters-detector.py 
alias proxy proxychains4
abbr -a g    git
abbr -a gs   git status
abbr -a ga   git add
abbr -a gaa  git add --all
abbr -a gc   git commit -m
abbr -a gca  git commit --amend --no-edit
abbr -a gd   git diff
abbr -a gds  git diff --staged
abbr -a gb   git branch
abbr -a gbd  git branch -d
abbr -a gco  git checkout
abbr -a gcob git checkout -b
abbr -a gsw  git switch
abbr -a gswc git switch -c
abbr -a gp   git push
abbr -a gpf  "git push --force-with-lease"
abbr -a gpu  git push -u origin HEAD
abbr -a gl   git pull
abbr -a gf   "git fetch --all --prune"
abbr -a glo  git log --oneline
abbr -a glg  "git log --oneline --graph --decorate"
abbr -a grl  git reflog
abbr -a gst  git stash
abbr -a gstp git stash pop
abbr -a grh  "git reset --hard HEAD"
abbr -a grs  git restore .
abbr -a grb  git rebase
abbr -a grbi git rebase -i

# aliases
alias adb /home/alina/Android/Sdk/platform-tools/adb
alias null "/dev/null"
alias top "btop"
alias ls "lsd -a"
#alias cat "bat -p"
alias catn "bat -p --style=numbers"
alias catc "bat -p --style=changes"
alias pw '_bump_text pwd'
alias py "python"
alias py3 "python3"
alias py2 "python2"
alias py3.11 "python3.11"
alias py3.10 "python3.10"
alias py3.9 "python3.9"
alias py3.8 "python3.8"
alias py3.7 "python3.7"
alias py3.6 "python3.6"
alias py2.7 "python2.7"
alias py2.6 "python2.6"
alias py2.5 "python2.5"
alias py2.4 "python2.4"
alias py2.3 "python2.3"
alias py2.2 "python2.2"
alias py2.1 "python2.1"
alias py2.0 "python2.0"
alias pip "pip3"
alias sc 'env ADB=$HOME/Android/Sdk/platform-tools/adb scrcpy'
alias fer ferium

function _bump_text
        eval $argv | sed 's/^/    /'
end
# starship
if status is-interactive
	starship init fish | source
	function _start_print
# 		echo " _   _       _            _       ";
# 		echo "| | | | __ _(_)_ __ _ __ (_)_ __  ";
# 		echo "| |_| |/ _` | | '__| '_ \| | '_ \ ";
# 		echo "|  _  | (_| | | |  | |_) | | | | |";
# 		echo "|_| |_|\__,_|_|_|  | .__/|_|_| |_|";
# 		echo "                   |_|            ";
# 		sleep 0.1
# 		echo "> Start fish | starship"
# 		sleep 0.1
# 		echo "-----------------"
# 		echo "> Name: $USERNAME"
# 		echo "> User: $USER"
# 		echo "> Host: $HOSTNAME"
# 		echo "> Shell: $SHELL"
# 		echo "-----------------"
# 		echo "> Uptime $(uptime -p)"
        	fastfetch || echo 'Start fish'
	end
	fish_default_key_bindings
	_start_print

end
# venv
source $HOME/.venv/bin/activate.fish

set -g PATH "$HOME/app-bin/:$PATH"

