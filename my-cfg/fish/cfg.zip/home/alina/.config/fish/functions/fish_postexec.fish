function fish_postexec --on-event fish_postexec
    if test -f /tmp/.last_job_crash
        # очищаем после того как юзер увидел и нажал ещё раз
        rm -f /tmp/.last_job_crash
    end
end
