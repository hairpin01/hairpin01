function fish_job_summary --on-event fish_job_summary
    set -l job_status $argv[2]
    set -l job_command $argv[3]

    if test $job_status -ne 0
        echo "$job_command (exit $job_status)" > /tmp/.last_job_crash
    else
        rm -f /tmp/.last_job_crash
    end
end
